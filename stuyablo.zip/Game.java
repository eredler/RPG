import java.util.Scanner;
import java.util.Random;

public class Game{
    
    public static Adventurer makePlayer(int n){
	Scanner userInput = new Scanner(System.in);

	Adventurer player;

       	System.out.println("What is your name?");
	String name = userInput.nextLine();

	player = choose(name);
	player.setNum(n);
	return player;
    }

    public static int chooseStat(int p){
	Scanner userInput = new Scanner(System.in);

	int d;

	try{
	    d = Integer.parseInt(userInput.nextLine());
	} catch (Exception e) {
	    System.out.println("Invalid number. Try again.");
	    d = chooseStat(p);
	}

	if (d <= 0 || d > (p-1)){
	    System.out.println("Your number must be greater than zero and less than " + (p-1) + ". Try again.");
	    d = chooseStat(p);
	}

	return d;
    }

    public static Adventurer choose(String name){
	Adventurer p;
	int Dex;
	int Str;
	int Int;
	int points = 30;

	Scanner userInput = new Scanner(System.in);

	System.out.println("Choose a class:\nA : Warrior\nB : Wizard\nC : Rogue\nD : Martial Artist");
	String type = userInput.nextLine();
	
	System.out.println("You have " + points + " points.\nChoose how many you would like to allocate towards your dexterity.\nPlease type a non-negative integer less than " + points + ".");
	Dex = chooseStat(points);
	points -= Dex;
	System.out.println("You have " + points + " points remaining.\nChoose how many you would like to allocate towards you strength.\nPlease type a non-negative integer less than " + points + ".");
	Str = chooseStat(points);
	points -= Str;
	Int = points;

	if (type.equalsIgnoreCase("A")){
	    p = new Warrior(name);
	} else if (type.equalsIgnoreCase("B")){
	    p = new Wizard(name);
	} else if (type.equalsIgnoreCase("C")){
	    p = new Rogue(name);
	} else if (type.equalsIgnoreCase("D")){
	    p = new MartialArtist(name);
	} else {
	    System.out.println("Please type either A, B, C, or D.");
	    p = choose(name);
	}     
	p.setDEX(Dex);
	p.setSTR(Str);
	p.setINT(Int);
        return p;
    }
	
    public static boolean checkSA(Adventurer p){
	if (p.getSA() >= 5){
	    return true;
	} else {
	    return false;
	}
    }

    public static int chooseAction(Adventurer p){
        int action;

	Scanner userInput = new Scanner(System.in);
	if (checkSA(p)) {
	    System.out.println("\nChoose an action:\nA : attack\nS : special attack\nG : give up");
	    String type = userInput.nextLine();
	
	    if (type.equalsIgnoreCase("A")){
		action = 0;
	    } else if (type.equalsIgnoreCase("S")){
		action = 2;
	    } else if (type.equalsIgnoreCase("G")){
		action = 1;
	    } else {
		System.out.println("Please type either A, S, or G.");
		action = chooseAction(p);
	    }
	}  else {
	    System.out.println("\nYou are no longer powerful enough for a special action!\nChoose an action:\nA : attack\nG : give up");
	    String type = userInput.nextLine();
	
	    if (type.equalsIgnoreCase("A")){
		action = 0;
	    } else if (type.equalsIgnoreCase("G")){
		action = 2;
	    } else {
		System.out.println("Please type either A or G.");
		action = chooseAction(p);
	    }
	}


        return action;
    }
    
    public static int hs(Adventurer[] players){
	int healthSum = 0;
	for (int x = 0; x < players.length; x++){
	    healthSum += players[x].getHP();
	}
	return healthSum;
    }

    public static boolean go(Adventurer defense, Adventurer offense, Adventurer p, boolean gu, int numPlayers,Adventurer[] players){
	Scanner userInput = new Scanner(System.in);
	boolean over = false;
	Random r = new Random();
	int healthSum = hs(players);
	if (healthSum > 0){
	    if (defense.getHP() > 0 && offense.getHP() > 0 && gu != true){

		int d;
		int o;

		defense.printStats();
		offense.printStats();

		if (offense.equals(p)){
		    o = chooseAction(p);
		    if (checkSA(defense)){
			d = r.nextInt(1); 
		    } else {
			d = 0;
		    }
		} else {
		    if (checkSA(offense)){
			o = r.nextInt(1); 
		    } else {
			o = 0;
		    }
		    d = chooseAction(p);
		}

		switch (o) {
		case 0: offense.attack(defense);
		    break;
		case 1: gu = true;
		    break;
		case 2: offense.specialAttack(defense);
		    break;
		}

		switch (d) {
		case 0: defense.attack(offense);
		    break;
		case 1: gu = true;
		    break;
		case 2: defense.specialAttack(offense);
		    break;
		}
	    } else {

		System.out.println("Game over!");

		if (defense.getHP() <= 0) {
		    System.out.println(defense.getName() + " has died.");
		    numPlayers--;
		} else if (offense.getHP() <= 0) {
		    System.out.println(offense.getName() + " has died.");
		    System.out.println("Players win!");
		} else if (offense.equals(p)) {
		    System.out.println(offense.getName() + " has given up.");
		    numPlayers--;
		} else if (defense.equals(p)) {
		    System.out.println(defense.getName() + " has given up.");
		    System.out.println(offense.getName() + "Players win!");
		}
		defense.printStats();
		offense.printStats();

	    }
	} else {
	    System.out.println("All players have died. Game over.");
	    over = true;
	}
	return over;
    }
    
    public static Adventurer setOpp(){
	Random r = new Random();
	int opp = r.nextInt(4);
	Adventurer o;
	if (opp == 0) {
	    o = new MartialArtist("Spongebob");
	} else if (opp == 1) {
	    o = new Warrior("Wario");
	} else if (opp == 2) {
	    o = new Wizard("Merlin");
	} else {
	    o = new Rogue("Jack Skellington");	   
	}
	return o;
    }

    public static int chooseNumPlay(){

	Scanner userInput = new Scanner(System.in);

	System.out.println("How many players? Choose a number from 1 to 4.");

	int numPlayers = Integer.parseInt(userInput.nextLine());

	if (numPlayers > 4 || numPlayers < 1){
	    System.out.println("Please choose a number of players, from 1 to 4.");
	    numPlayers = chooseNumPlay();
	}

	return numPlayers;

    }

    public static int randP(int n){
	Random r = new Random();
        int x = r.nextInt(n);
	int ans = 0;
	switch (n){
	case 0: ans = 1;
	    break;
	case 1: ans = 2;
	    break;
	case 2: ans = 3;
	    break;
	case 3: ans = 4;
	    break;
	}
	return ans;
    }

    public static void testGo(int x, Adventurer[] players, Adventurer opponent, Adventurer p1, Adventurer p2, Adventurer p3, Adventurer p4,int numPlayers){
	Random r = new Random();
	int n = players.length;
	switch (x){
	case 1: go(p1,opponent,p1,false,n,players);
	    break;
	case 2: go(p1,opponent,p1,false,n,players);
	    go(p2,opponent,p2,false,n,players);
	    break;
	case 3: go(p1,opponent,p1,false,n,players);
	    go(p2,opponent,p2,false,n,players);
	    go(p3,opponent,p3,false,n,players);
	    break;
	case 4: go(p1,opponent,p1,false,n,players);
	    go(p2,opponent,p2,false,n,players);
	    go(p3,opponent,p3,false,n,players);
	    go(p4,opponent,p4,false,n,players);
	    break;
	}
	if (checkHealth(p1)){
	    numPlayers--;
	}
        if (checkHealth(p2)){
	    numPlayers--;
	}
	if (checkHealth(p3)){
	    numPlayers--;
	}
	if (checkHealth(p4)){
	    numPlayers--;
	}    
	int thisTurn = r.nextInt(numPlayers);
	go(opponent,players[thisTurn],players[thisTurn],false,n,players);
	if (opponent.getHP() > 0){
	    testGo(numPlayers,players,opponent,p1,p2,p3,p4,numPlayers);
	}
    }

    public static void main(String[]args){
	Random r = new Random();
	Adventurer p1 = new Warrior();
	Adventurer p2 = new Warrior();
	Adventurer p3 = new Warrior();
	Adventurer p4 = new Warrior();
	Adventurer opponent;

	int numPlayers = chooseNumPlay();

	for (int n = numPlayers; n > 0; n--){
	    switch (n){
	    case 1: p1 = makePlayer(n);
		break;
	    case 2: p2 = makePlayer(n);
		break;
	    case 3: p3 = makePlayer(n);
		break;
	    case 4: p4 = makePlayer(n);
		break;
	    }
	}

	Adventurer[] players = new Adventurer[numPlayers];

	switch (numPlayers){
	case 1: players[0] = p1;
	    break;
	case 2: players[0] = p1;
	    players[1] = p2;
	    break;
	case 3: players[0] = p1;
	    players[1] = p2;
	    players[2] = p3;
	    break;
	case 4: players[0] = p1;
	    players[1] = p2;
	    players[2] = p3;
	    players[3] = p4;
	    break;
	}

	opponent = setOpp();
	
	testGo(numPlayers,players,opponent,p1,p2,p3,p4,numPlayers);
		       	   
    }

    public static boolean checkHealth(Adventurer who){
	if (who.getHP() <= 0){
	    who.setHP(0);
	    return true;
	}
	return false;
    }

  

}

